# Transcript Sorter: Project Guide

This file explains what the Transcript Sorter does, how it works, and how to change it safely.
It is written so it can be handed to Claude (or a person) in a future chat. The full source code is included at the end, so this file alone is enough to understand and modify the project.

## 1. Purpose

Medhavi Skills University, School of Design, issues academic transcripts as PDFs (one PDF per student). The SOD tracking sheet lists every student with their programme and passing status.

The tool takes:
- one Excel sheet (the full SOD sheet, or the user's own pass-only sheet for one programme),
- one programme chosen in a dropdown (for example "Bachelor of Vocation in Fashion Design", short name "BVoc FD"),
- a batch of transcript PDFs for that programme (up to 500 or more).

It produces:
- a folder named `<Short> Pass` (for example `BVoc FD Pass`) containing only the PDFs of students marked **Pass** for that programme,
- an Excel report `<Short> Report.xlsx` with these sheets:
  1. **Pass - Moved**: Pass students whose PDF was copied into the folder.
  2. **Fail - Not Moved**: Fail students who had a PDF; the PDF is not moved.
  3. **In Sheet - No PDF**: students in the sheet for this programme (Pass or Fail) with no PDF provided. Remark: "Not found in PDFs you provided".
  4. **PDF - Not In Sheet**: PDFs with no matching student in this programme. The remark gives the reason: not in the SOD sheet at all, listed under another programme, Registration No. could not be read, or a duplicate PDF.
  - **Summary**: the counts.

## 2. Requirements and running

| Item | Needed for | Minimum version |
|---|---|---|
| Python | everything | 3.10 |
| flask | web app | 3.0 (older Flask limits an upload to 1,000 parts) |
| openpyxl | reading the sheet, writing the report | 3.1 |
| pypdf | reading PDF text | 4.0 (older versions read text less reliably) |
| pytest | tests only | 8.0 |
| reportlab | tests only (creates fake PDFs) | 4.0 |

Check what is installed:

    python --version
    python -m pip show flask openpyxl pypdf pytest reportlab

Install anything missing (or everything at once with `python -m pip install -r requirements.txt`).

Run the tests, then the app, from the project folder:

    python -m pytest -v
    python app.py

`app.py` opens http://127.0.0.1:5000 in the browser. Everything runs locally; nothing is sent to the internet. Stop the app with Ctrl+C.

## 3. Using the page

1. **Student sheet**: upload the .xlsx. The app finds the header row and fills the programme dropdown from the Programme column.
2. **Programme**: choose one. Only that programme's rows are sorted.
3. **Transcript PDFs**: select the files or a whole folder (non-PDF files are ignored), then click **Sort transcripts**.
4. The page shows four coloured counts, the output folder path, and a button to download the folder and report as a zip.

Output goes to `output/<Short>_<date-time>/` inside the project folder. Each run gets a new folder, so earlier results are never overwritten.

## 4. Input formats

### Full SOD sheet
- Sheet "Data". Two rows of team labels on top; the **header is on row 3**. The app scans the first 15 rows of every sheet for a Registration column, so the exact row does not matter.
- Columns used (matched by header text, not position, case-insensitive):
  - Registration: "Registration Id", "Registration Number", "Registration No", "Reg No", "Registration"
  - Name: "Name", "Student Name", "Name of the Student"
  - Email: "Email", "Email ID"
  - Programme: "Programme", "Program"
  - Final Admission Category: "Final Admission Category"
  - Status: "Remarks Related to Passing Status", "Passing Status", "Status"
- Registration Ids are stored as numbers such as `22071020016005.0`; they are normalised to text `22071020016005` (spaces and a trailing `.0` are removed).
- Status values are trimmed and capitalised (" fail " becomes "Fail"). Only **Pass** is moved. A blank status is shown as "Blank" and treated as not Pass.
- Programmes seen in the real sheet: Bachelor of Design in Fashion Design (BDes FD), Bachelor of Design in Interior Design (BDes ID), Bachelor of Vocation in Fashion Design (BVoc FD), Bachelor of Vocation in Interior Design (BVoc ID), Master of Vocation in Fashion Design (MVoc FD), Master of Vocation in Interior Design (MVoc ID).

### User's own pass-only sheet
- Needs at least a Registration column. Name, Email and Final Admission Category are used if present.
- With **no Status column**, everyone is treated as Pass.
- With **no Programme column**, every row belongs to the programme picked in the dropdown, and the dropdown shows the six standard programmes.

### Transcript PDFs
- Text-based PDFs (not scans), 2 pages, about 9 MB each.
- Page 1 contains lines like `Name of the Student : Aarpita Dhoot` and `Registration No. : 22071010029014`.
- File names look like `Aarpita Dhoot_6a23f47c09b96ec7c39e3d38.pdf`. The file name is only a fallback for the displayed name (the `_id` part is removed) and is **never** used for matching.

## 5. Matching rules (the important part)

- Matching uses **Registration Number only**. Names are not used because spellings differ between PDFs and the sheet (for example "Aagana Kaushikbhai Patel" in the PDF and "Aagana Kaushik Bhai Patel" in the sheet).
- For each PDF, in upload order:
  - No Registration No. could be read → Sheet 4, "Could not read Registration No. - <reason>".
  - Same Registration No. as an earlier PDF → Sheet 4, "Duplicate PDF ... (not moved)". Only the first PDF is used.
  - Registration found for this programme and status Pass → copied to the Pass folder, Sheet 1.
  - Registration found for this programme and status not Pass → Sheet 2, not moved.
  - Registration found in the sheet under a different programme → Sheet 4, "In SOD sheet under another programme: <name>".
  - Otherwise → Sheet 4, "Not found in SOD sheet".
- Students of this programme with no matching PDF → Sheet 3.
- Duplicate rows for the same Registration in the sheet count once (the first row is used).
- PDFs are **copied**, not moved, so the originals are untouched. The uploaded copies are deleted after each run.

## 6. Code structure

| File | Role |
|---|---|
| `app.py` | Flask web app: home page, `/api/programmes` (reads the sheet and returns its programmes), `/api/process` (saves the uploads and runs the pipeline), `/download/<id>` (zips the run folder). |
| `templates/index.html` | The page: Times New Roman, navy/saffron/teal palette, colour-coded result tiles, upload progress bar. |
| `sorter/models.py` | Data classes: `Student`, `PdfInfo`, `Match`, `Result`. |
| `sorter/sheet.py` | Finds the header row and columns, normalises Registration numbers, lists programmes, loads students, makes short names. |
| `sorter/pdfinfo.py` | Reads page 1 of a PDF with pypdf and extracts Name and Registration No. with regular expressions. |
| `sorter/classify.py` | Pure matching logic; puts every student and PDF into one of the four buckets. |
| `sorter/report.py` | Writes the 4-sheet report plus Summary (coloured headers, Times New Roman). |
| `sorter/pipeline.py` | Runs everything in order: load students, read PDFs, classify, copy Pass PDFs, write report. |
| `tests/` | 34 pytest tests. `conftest.py` builds small fake sheets and PDFs; `fixtures/Aarpita_Dhoot_sample.pdf` is a real transcript. |

Data flow:

    Excel ──sheet.py──► students (this programme) + registration→programme map (all programmes)
    PDFs  ──pdfinfo.py─► (name, registration) per PDF
                 └──► classify.py ──► Result(passed, failed, no_pdf, not_in_sheet)
                                     ├─► pipeline.py copies passed PDFs to "<Short> Pass/"
                                     └─► report.py writes "<Short> Report.xlsx"

## 7. Tests (test-driven development)

The project was built test-first: tests were written before the code and confirmed to fail, then the code was written until they passed.

- `test_sheet.py`: Registration normalisation, short names, programme list, Pass/Fail reading, pass-only sheet, missing Registration column.
- `test_pdfinfo.py`: text parsing (separate lines and same-line layout), the real sample PDF, the file-name fallback, broken PDFs.
- `test_classify.py`: the four buckets, other programme, unreadable PDF, duplicate PDFs, duplicate sheet rows.
- `test_pipeline.py`: a full run with the SOD-style sheet, the pass-only sheet, and a re-run that must not overwrite.
- `test_app.py`: the page uses Times New Roman, the programmes endpoint, process and download, and missing-input errors.

Run with `python -m pytest -v`. All 34 should pass.

Verified on real data: the SOD sheet (BVoc FD: 254 Pass, 65 Fail) and 5 real PDFs gave 4 Pass moved, 1 PDF flagged "under another programme" (an Interior Design student), and 315 FD students without PDFs.

## 8. Known limits

- About 0.5 seconds per PDF, so 500 PDFs take around 4 minutes after the upload finishes.
- Scanned PDFs with no text layer cannot be read; they go to Sheet 4 as "Could not read Registration No." (OCR is not included).
- Only `.xlsx` / `.xlsm` sheets are accepted (not `.xls` or `.csv`).
- Download links are kept in memory, so they stop working after the app restarts. The files remain in the `output` folder.

## 9. How to ask for changes in a future chat

Attach this file (and the project zip if available) and say what to change. Ask Claude to keep the same approach:
1. Write or update a test in `tests/` that describes the new behaviour, and confirm it fails.
2. Change the code until all tests pass.
3. Keep matching by Registration Number unless told otherwise.

Example requests:
- "Also put Fail PDFs into a separate `<Short> Fail` folder."
- "Accept .csv sheets as well as .xlsx."
- "Add the Month and Year of Passing column to Sheet 1."
- "Speed up PDF reading using several processes."

## 10. Related earlier work (context)

Before this tool, the same conversation checked transcript PDFs against the SOD sheet's semester columns (Max Marks, Max Credits, Obtained Marks, Obtained Credit Points, SGPA per semester, plus Overall). The rules used there were:
- Max Marks = number of subjects × 100. Max Credits = sum of T-P-PR credits. Credit points = credit × grade point, summed.
- SGPA = credit points ÷ credits, rounded half-up to 1 decimal (6.85 → 6.9).
- OLD grade scale: O 99–100 = 10, A+ 90–98 = 9, A 80–89 = 8, B+ 70–79 = 7, B 60–69 = 6, C 50–59 = 5, P 40–49 = 4, F below 40 = 0.
- NEW grade scale: O 90–100, A+ 80–89, A 70–79, B+ 60–69, B 50–59, C 45–49, P 40–44, F below 40 (same points).
- Finding: Vanshika Jindal (220710200672), Sem 5 SGPA should be 192 ÷ 22 = 8.727 → 8.7, but both the PDF and the sheet show 8.8.

That checker is not part of this project's code; it could be added later as a separate feature.

## 11. Full source code

### `requirements.txt`

```text
flask>=3.0
openpyxl>=3.1
pypdf>=4.0
pytest>=8.0
reportlab>=4.0
```

### `app.py`

```python
"""Transcript Sorter - local web app.  Run:  python app.py   then open http://127.0.0.1:5000"""
import re, shutil, tempfile, uuid, zipfile
from pathlib import Path
from flask import Flask, jsonify, render_template, request, send_file, abort
from werkzeug.utils import secure_filename
from sorter.sheet import list_programmes, short_name
from sorter.pipeline import run

KNOWN = ["Bachelor of Design in Fashion Design", "Bachelor of Design in Interior Design",
         "Bachelor of Vocation in Fashion Design", "Bachelor of Vocation in Interior Design",
         "Master of Vocation in Fashion Design", "Master of Vocation in Interior Design"]


def _safe_name(filename: str) -> str:
    name = Path(filename.replace("\\", "/")).name          # drop folder part from folder uploads
    name = re.sub(r'[<>:"|?*\x00-\x1f]', "_", name).strip(" .")
    return name or secure_filename(filename) or "file.pdf"


def create_app(work_dir="output"):
    app = Flask(__name__)
    app.config["MAX_CONTENT_LENGTH"] = None          # 500 PDFs x ~9 MB is fine locally
    app.config["MAX_FORM_PARTS"] = 10000
    app.config["MAX_FORM_MEMORY_SIZE"] = None
    work = Path(work_dir).resolve(); work.mkdir(parents=True, exist_ok=True)
    runs = {}

    def _save_sheet(tmp):
        f = request.files.get("sheet")
        if not f or not f.filename.lower().endswith((".xlsx", ".xlsm")):
            abort(400, "Please upload the sheet as .xlsx")
        p = tmp / "sheet.xlsx"; f.save(p); return p

    @app.errorhandler(400)
    def bad(e):
        return jsonify(error=str(e.description)), 400

    @app.get("/")
    def home():
        return render_template("index.html", known=[{"name": k, "short": short_name(k)} for k in KNOWN])

    @app.post("/api/programmes")
    def programmes():
        with tempfile.TemporaryDirectory() as t:
            try:
                progs = list_programmes(_save_sheet(Path(t)))
            except ValueError as e:
                abort(400, str(e))
        return jsonify(programmes=[{"name": p, "short": short_name(p)} for p in progs])

    @app.post("/api/process")
    def process():
        programme = (request.form.get("programme") or "").strip()
        pdfs = [f for f in request.files.getlist("pdfs") if f.filename.lower().endswith(".pdf")]
        if not programme:
            abort(400, "Please choose a programme.")
        if not pdfs:
            abort(400, "Please add the PDF transcripts.")
        tmp = Path(tempfile.mkdtemp(prefix="ts_", dir=work))
        try:
            sheet = _save_sheet(tmp)
            pdf_dir = tmp / "pdfs"; pdf_dir.mkdir()
            paths = []
            for f in pdfs:
                dest = pdf_dir / _safe_name(f.filename)
                n = 1
                while dest.exists():                       # same file name twice
                    dest = pdf_dir / f"{dest.stem}({n}){dest.suffix}"; n += 1
                f.save(dest); paths.append(dest)
            try:
                res = run(sheet, programme, paths, work)
            except ValueError as e:
                abort(400, str(e))
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
        rid = uuid.uuid4().hex
        runs[rid] = res.run_dir
        return jsonify(counts=res.counts, folder=str(res.pass_folder), report=str(res.report_path),
                       download=f"/download/{rid}", short=short_name(programme))

    @app.get("/download/<rid>")
    def download(rid):
        run_dir = runs.get(rid) or abort(404)
        zpath = run_dir.with_suffix(".zip")
        if not zpath.exists():
            with zipfile.ZipFile(zpath, "w", zipfile.ZIP_STORED) as z:   # PDFs are already compressed
                for p in run_dir.rglob("*"):
                    if p.is_file():
                        z.write(p, p.relative_to(run_dir))
        return send_file(zpath, as_attachment=True, download_name=zpath.name)

    return app


if __name__ == "__main__":
    import webbrowser
    webbrowser.open("http://127.0.0.1:5000")
    create_app(Path(__file__).parent / "output").run(port=5000, threaded=True)
```

### `templates/index.html`

```html
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Transcript Sorter · School of Design</title>
<style>
  :root{
    --ink:#1b2a3a; --muted:#5b6b7c; --paper:#f6f8fb; --card:#ffffff; --line:#d8e1ea;
    --navy:#1f5f8b; --saffron:#e39b2d; --teal:#17807e;
    --pass:#1e7b5a; --fail:#b03a48; --nopdf:#c77d1a; --nosheet:#3d5a99;
  }
  *{box-sizing:border-box}
  body{margin:0;font-family:"Times New Roman",Times,serif;color:var(--ink);background:var(--paper);font-size:18px;line-height:1.5}
  header{background:var(--navy);color:#fff;padding:28px 24px 34px;border-bottom:6px solid var(--saffron)}
  header .wrap{max-width:980px;margin:auto}
  h1{margin:0;font-size:2.2rem;font-weight:700;letter-spacing:.3px}
  header p{margin:6px 0 0;color:#dbe8f3;max-width:62ch}
  main{max-width:980px;margin:-18px auto 40px;padding:0 16px}
  .step{background:var(--card);border:1px solid var(--line);border-left:6px solid var(--teal);border-radius:10px;padding:20px 22px;margin-bottom:16px}
  .step:nth-of-type(2){border-left-color:var(--saffron)}
  .step:nth-of-type(3){border-left-color:var(--navy)}
  .step h2{margin:0 0 4px;font-size:1.3rem;display:flex;gap:10px;align-items:baseline}
  .num{display:inline-grid;place-items:center;width:30px;height:30px;border-radius:50%;background:var(--ink);color:#fff;font-size:1rem}
  .hint{color:var(--muted);margin:0 0 12px;font-size:1rem}
  .drop{display:block;border:2px dashed var(--line);border-radius:8px;padding:18px;text-align:center;cursor:pointer;background:#fbfcfe;transition:border-color .15s,background .15s}
  .drop:hover,.drop.over{border-color:var(--teal);background:#eef7f6}
  .drop input{display:none}
  .chosen{margin-top:8px;font-style:italic;color:var(--teal)}
  select{width:100%;font:inherit;padding:10px 12px;border:1px solid var(--line);border-radius:8px;background:#fff}
  .row{display:flex;gap:10px;flex-wrap:wrap}
  .row .drop{flex:1 1 240px}
  button{font:inherit;font-weight:700;border:0;border-radius:8px;padding:12px 26px;cursor:pointer;background:var(--saffron);color:#2a1a00}
  button:disabled{opacity:.45;cursor:not-allowed}
  button:focus-visible,select:focus-visible,.drop:focus-within{outline:3px solid var(--navy);outline-offset:2px}
  .bar{height:10px;background:var(--line);border-radius:6px;overflow:hidden;margin-top:14px;display:none}
  .bar i{display:block;height:100%;width:0;background:linear-gradient(90deg,var(--teal),var(--navy));transition:width .2s}
  #status{margin-top:8px;color:var(--muted)}
  .err{color:var(--fail);font-weight:700}
  #result{display:none}
  .tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px;margin:14px 0}
  .tile{border-radius:10px;padding:14px 16px;color:#fff}
  .tile b{display:block;font-size:2.3rem;line-height:1.1}
  .tile span{font-size:1rem}
  .t1{background:var(--pass)} .t2{background:var(--fail)} .t3{background:var(--nopdf)} .t4{background:var(--nosheet)}
  .path{font-size:.95rem;color:var(--muted);word-break:break-all}
  a.dl{display:inline-block;text-decoration:none;background:var(--navy);color:#fff;padding:12px 26px;border-radius:8px;font-weight:700}
  @media (prefers-reduced-motion:reduce){*{transition:none!important}}
</style>
</head>
<body>
<header><div class="wrap">
  <h1>Transcript Sorter</h1>
  <p>Give it the SOD sheet and a programme's transcript PDFs. Passed students' PDFs go into one folder, and a four-sheet report explains everyone else.</p>
</div></header>

<main>
  <section class="step">
    <h2><span class="num">1</span>Student sheet</h2>
    <p class="hint">The full SOD sheet (all programmes, Pass and Fail), or your own sheet for one programme with only Pass students.</p>
    <label class="drop" id="sheetDrop"><input type="file" id="sheet" accept=".xlsx,.xlsm">Click or drop the Excel file here
      <div class="chosen" id="sheetName"></div></label>
  </section>

  <section class="step">
    <h2><span class="num">2</span>Programme</h2>
    <p class="hint" id="progHint">Programmes in your sheet appear here after step 1.</p>
    <select id="programme"><option value="">Choose a programme</option>
      {% for p in known %}<option value="{{p.name}}">{{p.short}} · {{p.name}}</option>{% endfor %}
    </select>
  </section>

  <section class="step">
    <h2><span class="num">3</span>Transcript PDFs</h2>
    <p class="hint">Pick the whole folder or select the files; up to 500 or more is fine.</p>
    <div class="row">
      <label class="drop" id="pdfDrop"><input type="file" id="pdfs" accept=".pdf" multiple>Select PDF files</label>
      <label class="drop"><input type="file" id="folder" webkitdirectory multiple>Select a folder</label>
    </div>
    <div class="chosen" id="pdfCount"></div>
    <p style="margin:16px 0 0"><button id="go" disabled>Sort transcripts</button></p>
    <div class="bar" id="bar"><i></i></div>
    <div id="status" aria-live="polite"></div>
  </section>

  <section class="step" id="result" aria-live="polite">
    <h2>Result for <span id="rProg"></span></h2>
    <div class="tiles">
      <div class="tile t1"><b id="c1">0</b><span>Pass · PDF moved to folder</span></div>
      <div class="tile t2"><b id="c2">0</b><span>Fail · PDF not moved</span></div>
      <div class="tile t3"><b id="c3">0</b><span>In sheet · no PDF found</span></div>
      <div class="tile t4"><b id="c4">0</b><span>PDF · not in sheet</span></div>
    </div>
    <p class="path">Pass folder: <span id="rFolder"></span><br>Report: <span id="rReport"></span></p>
    <a class="dl" id="dl" href="#">Download folder + report (.zip)</a>
  </section>
</main>

<script>
const $ = id => document.getElementById(id);
let sheetFile = null, pdfFiles = [];
const known = $("programme").innerHTML;

function ready(){ $("go").disabled = !(sheetFile && $("programme").value && pdfFiles.length); }
function status(msg, err){ $("status").innerHTML = err ? `<span class="err">${msg}</span>` : msg; }

async function setSheet(f){
  sheetFile = f; $("sheetName").textContent = f.name; ready();
  const fd = new FormData(); fd.append("sheet", f);
  const r = await fetch("/api/programmes", {method:"POST", body:fd}); const j = await r.json();
  if(!r.ok){ status(j.error, true); return; }
  status("");
  if(j.programmes.length){
    $("programme").innerHTML = '<option value="">Choose a programme</option>' +
      j.programmes.map(p => `<option value="${p.name}">${p.short} · ${p.name}</option>`).join("");
    $("progHint").textContent = `${j.programmes.length} programmes found in this sheet. Only the chosen one is processed.`;
  } else {
    $("programme").innerHTML = known;
    $("progHint").textContent = "This sheet has no Programme column, so everyone in it is treated as Pass for the programme you pick.";
  }
  ready();
}
function setPdfs(list){
  pdfFiles = [...list].filter(f => f.name.toLowerCase().endsWith(".pdf"));
  $("pdfCount").textContent = `${pdfFiles.length} PDF${pdfFiles.length==1?"":"s"} selected`; ready();
}
$("sheet").onchange = e => e.target.files[0] && setSheet(e.target.files[0]);
$("pdfs").onchange = e => setPdfs(e.target.files);
$("folder").onchange = e => setPdfs(e.target.files);
$("programme").onchange = ready;
for (const [id, fn] of [["sheetDrop", fs => fs[0] && setSheet(fs[0])], ["pdfDrop", setPdfs]]) {
  const el = $(id);
  el.ondragover = e => { e.preventDefault(); el.classList.add("over"); };
  el.ondragleave = () => el.classList.remove("over");
  el.ondrop = e => { e.preventDefault(); el.classList.remove("over"); fn(e.dataTransfer.files); };
}

$("go").onclick = () => {
  const fd = new FormData();
  fd.append("sheet", sheetFile); fd.append("programme", $("programme").value);
  pdfFiles.forEach(f => fd.append("pdfs", f, f.name));
  const x = new XMLHttpRequest(); x.open("POST", "/api/process");
  $("go").disabled = true; $("bar").style.display = "block"; $("result").style.display = "none";
  x.upload.onprogress = e => { if(e.lengthComputable){ const p = e.loaded/e.total*100;
    $("bar").firstElementChild.style.width = p + "%";
    status(p < 100 ? `Uploading ${Math.round(p)}%` : "Reading PDFs and sorting, please wait"); } };
  x.onload = () => {
    $("go").disabled = false; const j = JSON.parse(x.responseText || "{}");
    if (x.status !== 200){ status(j.error || "Something went wrong.", true); return; }
    status("Done.");
    $("c1").textContent = j.counts.passed; $("c2").textContent = j.counts.failed;
    $("c3").textContent = j.counts.no_pdf; $("c4").textContent = j.counts.not_in_sheet;
    $("rProg").textContent = j.short; $("rFolder").textContent = j.folder; $("rReport").textContent = j.report;
    $("dl").href = j.download; $("result").style.display = "block";
    $("result").scrollIntoView({behavior:"smooth"});
  };
  x.onerror = () => { $("go").disabled = false; status("Upload failed. Is the app still running?", true); };
  x.send(fd);
};
</script>
</body>
</html>
```

### `sorter/models.py`

```python
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class Student:
    name: str
    reg: str
    email: str
    programme: str
    admission_category: str
    status: str                      # "Pass", "Fail", or whatever the sheet says

    @property
    def is_pass(self) -> bool:
        return self.status.strip().lower() == "pass"


@dataclass
class PdfInfo:
    path: Path
    name: str
    reg: str
    error: str = ""


@dataclass
class Match:
    student: Student
    pdf: PdfInfo


@dataclass
class Result:
    passed: list = field(default_factory=list)        # [Match]  -> moved to folder
    failed: list = field(default_factory=list)        # [Match]  -> not moved
    no_pdf: list = field(default_factory=list)        # [Student]
    not_in_sheet: list = field(default_factory=list)  # [(PdfInfo, reason)]
```

### `sorter/sheet.py`

```python
"""Reads the SOD sheet (full sheet with all programmes) or a user's own pass-only sheet."""
import re
from openpyxl import load_workbook
from .models import Student

# accepted header spellings (compared lower-case, spaces collapsed)
ALIASES = {
    "reg": ["registration id", "registration number", "registration no", "registration no.", "reg no", "registration"],
    "name": ["name", "student name", "name of the student"],
    "email": ["email", "email id", "email id of the student"],
    "programme": ["programme", "program"],
    "admission": ["final admission category"],
    "status": ["remarks related to passing status", "passing status", "status"],
}
ABBR = [("Bachelor of Vocation", "BVoc"), ("Bachelor of Design", "BDes"), ("Master of Vocation", "MVoc"),
        ("Master of Design", "MDes"), ("Fashion Design", "FD"), ("Interior Design", "ID")]


def normalize_reg(value) -> str:
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        value = int(value)
    s = re.sub(r"\s+", "", str(value))
    return s[:-2] if s.endswith(".0") else s


def short_name(programme: str) -> str:
    out = programme
    for full, ab in ABBR:
        out = re.sub(re.escape(full), ab, out, flags=re.I)
    out = re.sub(r"\s+in\s+", " ", out)
    return out.strip()


def _clean(v) -> str:
    return re.sub(r"\s+", " ", str(v)).strip() if v is not None else ""


def _find_table(path):
    """Return (rows_after_header, column_index_map) for the first sheet that has a Registration column."""
    wb = load_workbook(path, read_only=True, data_only=True)
    try:
        for ws in wb.worksheets:
            rows = ws.iter_rows(values_only=True)
            for _ in range(15):                      # header must be in the first 15 rows
                row = next(rows, None)
                if row is None:
                    break
                heads = [_clean(c).lower() for c in row]
                cols = {}
                for key, names in ALIASES.items():
                    for i, h in enumerate(heads):
                        if h in names:
                            cols[key] = i
                            break
                if "reg" in cols:
                    return [r for r in rows], cols
        raise ValueError("No 'Registration Id' / 'Registration Number' column found in any sheet.")
    finally:
        wb.close()


def _get(row, cols, key):
    i = cols.get(key)
    return row[i] if i is not None and i < len(row) else None


def list_programmes(path) -> list:
    rows, cols = _find_table(path)
    if "programme" not in cols:
        return []
    return sorted({_clean(_get(r, cols, "programme")) for r in rows if _clean(_get(r, cols, "programme"))})


def all_regs_by_programme(path) -> dict:
    rows, cols = _find_table(path)
    out = {}
    for r in rows:
        reg = normalize_reg(_get(r, cols, "reg"))
        if reg:
            out.setdefault(reg, _clean(_get(r, cols, "programme")))
    return out


def load_students(path, programme: str) -> list:
    rows, cols = _find_table(path)
    has_prog, has_status = "programme" in cols, "status" in cols
    students = []
    for r in rows:
        reg = normalize_reg(_get(r, cols, "reg"))
        if not reg:
            continue
        prog = _clean(_get(r, cols, "programme")) if has_prog else programme
        if has_prog and prog.lower() != programme.strip().lower():
            continue
        status = _clean(_get(r, cols, "status")).capitalize() if has_status else "Pass"
        students.append(Student(name=_clean(_get(r, cols, "name")), reg=reg,
                                email=_clean(_get(r, cols, "email")), programme=prog or programme,
                                admission_category=_clean(_get(r, cols, "admission")),
                                status=status or "Blank"))
    return students
```

### `sorter/pdfinfo.py`

```python
"""Reads Name and Registration No. from page 1 of a transcript PDF."""
import re
from pathlib import Path
from pypdf import PdfReader
from .models import PdfInfo

REG_RE = re.compile(r"Registration\s*No\.?\s*:\s*([0-9A-Za-z/-]+)", re.I)
NAME_RE = re.compile(r"Name of the Student\s*:[ \t]*(.*?)(?=\s{3,}|\s*Registration|\n|$)", re.I)


def parse_transcript_text(text: str):
    reg = REG_RE.search(text or "")
    name = NAME_RE.search(text or "")
    return (name.group(1).strip() if name else "", reg.group(1).strip() if reg else "")


def _name_from_filename(path: Path) -> str:
    return re.sub(r"_[0-9A-Za-z]*\d[0-9A-Za-z]*$", "", path.stem).replace("_", " ").strip()


def read_pdf(path) -> PdfInfo:
    path = Path(path)
    try:
        text = PdfReader(str(path)).pages[0].extract_text() or ""
    except Exception as e:                              # broken / encrypted / not a PDF
        return PdfInfo(path=path, name=_name_from_filename(path), reg="", error=f"Cannot open PDF ({e.__class__.__name__})")
    name, reg = parse_transcript_text(text)
    return PdfInfo(path=path, name=name or _name_from_filename(path), reg=reg,
                   error="" if reg else "No Registration No. text in PDF (scanned?)")
```

### `sorter/classify.py`

```python
"""Pure logic: put every student / PDF into one of the 4 report buckets."""
from .models import Match, Result


def classify(students, pdfs, other_programmes: dict) -> Result:
    res = Result()
    by_reg = {}
    for s in students:                       # duplicate rows in sheet -> keep first
        by_reg.setdefault(s.reg, s)
    used = set()
    for p in pdfs:
        if not p.reg:
            res.not_in_sheet.append((p, f"Could not read Registration No. - {p.error}"))
        elif p.reg in used:
            res.not_in_sheet.append((p, "Duplicate PDF for same Registration Number (not moved)"))
        elif p.reg in by_reg:
            used.add(p.reg)
            s = by_reg[p.reg]
            (res.passed if s.is_pass else res.failed).append(Match(s, p))
        elif other_programmes.get(p.reg):
            res.not_in_sheet.append((p, f"In SOD sheet under another programme: {other_programmes[p.reg]}"))
        else:
            res.not_in_sheet.append((p, "Not found in SOD sheet"))
    res.no_pdf = [s for reg, s in by_reg.items() if reg not in used]
    return res
```

### `sorter/report.py`

```python
"""Writes the 4-sheet Excel report."""
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

COLORS = {"1. Pass - Moved": "1E7B5A", "2. Fail - Not Moved": "B03A48",
          "3. In Sheet - No PDF": "C77D1A", "4. PDF - Not In Sheet": "3D5A99", "Summary": "5B3E8C"}


def _sheet(wb, title, headers, rows):
    ws = wb.create_sheet(title)
    ws.append(headers)
    for i, r in enumerate(rows, 1):
        ws.append([i, *r])
    fill = PatternFill("solid", fgColor=COLORS[title])
    for c in ws[1]:
        c.font = Font(name="Times New Roman", bold=True, color="FFFFFF")
        c.fill = fill
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    for row in ws.iter_rows(min_row=2):
        for c in row:
            c.font = Font(name="Times New Roman")
    for col in ws.columns:
        ws.column_dimensions[col[0].column_letter].width = min(60, max(10, *(len(str(c.value or "")) + 2 for c in col)))
    ws.freeze_panes = "A2"
    ws.sheet_properties.tabColor = COLORS[title]
    return ws


def write_report(res, programme, path):
    wb = Workbook(); wb.remove(wb.active)
    student_cols = ["S.No", "Name (Sheet)", "Registration Number", "Email", "Programme",
                    "Final Admission Category", "Status", "Name (PDF)", "PDF File"]
    m_row = lambda m: [m.student.name, m.student.reg, m.student.email, m.student.programme,
                       m.student.admission_category, m.student.status, m.pdf.name, m.pdf.path.name]
    _sheet(wb, "1. Pass - Moved", student_cols, [m_row(m) for m in res.passed])
    _sheet(wb, "2. Fail - Not Moved", student_cols, [m_row(m) for m in res.failed])
    _sheet(wb, "3. In Sheet - No PDF", ["S.No", "Name", "Registration Number", "Status (Pass/Fail)", "Remark", "Email"],
           [[s.name, s.reg, s.status, "Not found in PDFs you provided", s.email] for s in res.no_pdf])
    _sheet(wb, "4. PDF - Not In Sheet", ["S.No", "Name (PDF)", "Registration Number (PDF)", "PDF File", "Remark"],
           [[p.name, p.reg, p.path.name, why] for p, why in res.not_in_sheet])
    _sheet(wb, "Summary", ["S.No", "Item", "Count"], [
        ["Programme", programme], ["Pass - PDF moved to folder", len(res.passed)],
        ["Fail - PDF not moved", len(res.failed)], ["In sheet - no PDF", len(res.no_pdf)],
        ["PDF - not in sheet", len(res.not_in_sheet)]])
    wb.save(path)
    return path
```

### `sorter/pipeline.py`

```python
"""Glue: sheet + PDFs -> '<Short> Pass' folder + report."""
import shutil
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from .sheet import load_students, all_regs_by_programme, short_name
from .pdfinfo import read_pdf
from .classify import classify
from .report import write_report


@dataclass
class RunResult:
    run_dir: Path
    pass_folder: Path
    report_path: Path
    counts: dict


def run(sheet_path, programme, pdf_paths, out_root, progress=None) -> RunResult:
    students = load_students(sheet_path, programme)
    others = {r: p for r, p in all_regs_by_programme(sheet_path).items()
              if p and p.lower() != programme.lower()}
    pdfs = []
    for i, p in enumerate(pdf_paths, 1):
        pdfs.append(read_pdf(p))
        if progress:
            progress(i, len(pdf_paths))
    res = classify(students, pdfs, others)

    short = short_name(programme)
    stamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S-%f")
    run_dir = Path(out_root) / f"{short}_{stamp}"
    folder = run_dir / f"{short} Pass"
    folder.mkdir(parents=True)
    for m in res.passed:
        shutil.copy2(m.pdf.path, folder / m.pdf.path.name)
    report = write_report(res, programme, run_dir / f"{short} Report.xlsx")
    counts = {"passed": len(res.passed), "failed": len(res.failed),
              "no_pdf": len(res.no_pdf), "not_in_sheet": len(res.not_in_sheet)}
    return RunResult(run_dir, folder, report, counts)
```

### `tests/conftest.py`

```python
"""Shared test fixtures: tiny fake SOD sheets and fake transcript PDFs."""
import pytest
from openpyxl import Workbook
from reportlab.pdfgen import canvas

FULL_HEADERS = ["Exit Year as per Admission", "Registration Id", "Old Reg No", "Application Number",
                "Name", "Email", "Programme", "Final Centre Name", "Final and Updated sem", "User ID",
                "Entry Category", "Admission Category", "Final Admission Category", "Admission Intake",
                "Remarks Related to Passing Status"]
FD = "Bachelor of Vocation in Fashion Design"
ID = "Bachelor of Vocation in Interior Design"


def full_row(reg, name, prog, status, email=None):
    r = [""] * len(FULL_HEADERS)
    r[1], r[4], r[5], r[6] = reg, name, email or f"{name.split()[0].lower()}@msu.edu.in", prog
    r[12], r[14] = "Regular Admission to First Year", status
    return r


@pytest.fixture
def full_sheet(tmp_path):
    """Like the real SOD sheet: 2 junk rows on top, header on row 3, float reg numbers."""
    wb = Workbook(); ws = wb.active; ws.title = "Data"
    ws.append(["", "Exam team"]); ws.append([])
    ws.append(FULL_HEADERS)
    ws.append(full_row(22071020016005.0, "Aagana Patel", FD, "Pass"))
    ws.append(full_row(22071020029002.0, "Abonita Dhara", FD, "Pass"))
    ws.append(full_row(22071020011111.0, "Fail Person", FD, "Fail"))
    ws.append(full_row(22071020022222.0, "Missing Pdf Pass", FD, "Pass"))
    ws.append(full_row(22071020033333.0, "Missing Pdf Fail", FD, " fail "))
    ws.append(full_row(22071010029014.0, "Aarpita Dhoot", ID, "Pass"))
    wb.create_sheet("Notes").append(["just notes"])
    p = tmp_path / "sod.xlsx"; wb.save(p); return p


@pytest.fixture
def pass_only_sheet(tmp_path):
    """The user's own per-programme sheet: only Pass students, no Programme / Remarks column."""
    wb = Workbook(); ws = wb.active
    ws.append(["Name", "Registration Number", "Email", "Final Admission Category"])
    ws.append(["Aagana Patel", "22071020016005", "a@msu.edu.in", "Regular"])
    ws.append(["Missing Pdf Pass", " 22071020022222 ", "m@msu.edu.in", "Regular"])
    p = tmp_path / "mine.xlsx"; wb.save(p); return p


def make_pdf(path, name, reg):
    c = canvas.Canvas(str(path))
    c.drawString(50, 800, "ACADEMIC TRANSCRIPT")
    c.drawString(50, 780, f"Name of the Student : {name}")
    c.drawString(50, 760, f"Registration No. : {reg}")
    c.drawString(50, 740, "Programme : Bachelor of Vocation")
    c.save(); return path


@pytest.fixture
def pdf_dir(tmp_path):
    d = tmp_path / "pdfs"; d.mkdir()
    make_pdf(d / "Aagana_1.pdf", "Aagana Kaushikbhai Patel", "22071020016005")
    make_pdf(d / "Abonita_2.pdf", "Abonita Dhara", "22071020029002")
    make_pdf(d / "Fail_3.pdf", "Fail Person", "22071020011111")
    make_pdf(d / "Stranger_4.pdf", "Stranger Person", "99999999999999")
    make_pdf(d / "Aarpita_5.pdf", "Aarpita Dhoot", "22071010029014")   # other programme
    (d / "broken.pdf").write_bytes(b"not a pdf")
    return d
```

### `tests/test_sheet.py`

```python
import pytest
from sorter.sheet import normalize_reg, short_name, load_students, list_programmes
from tests.conftest import FD, ID


@pytest.mark.parametrize("raw,expected", [
    (22071020016005.0, "22071020016005"), (22071020016005, "22071020016005"),
    ("22071020016005.0", "22071020016005"), (" 2207 1020016005 ", "22071020016005"),
    (None, ""), ("", ""),
])
def test_normalize_reg(raw, expected):
    assert normalize_reg(raw) == expected


@pytest.mark.parametrize("full,short", [
    ("Bachelor of Vocation in Fashion Design", "BVoc FD"),
    ("Bachelor of Vocation in Interior Design", "BVoc ID"),
    ("Bachelor of Design in Fashion Design", "BDes FD"),
    ("Master of Vocation in Interior Design", "MVoc ID"),
    ("Some New Course", "Some New Course"),
])
def test_short_name(full, short):
    assert short_name(full) == short


def test_list_programmes_full_sheet(full_sheet):
    assert list_programmes(full_sheet) == [FD, ID]


def test_list_programmes_sheet_without_programme_column(pass_only_sheet):
    assert list_programmes(pass_only_sheet) == []


def test_load_students_filters_programme_and_reads_status(full_sheet):
    s = load_students(full_sheet, FD)
    assert [x.reg for x in s] == ["22071020016005", "22071020029002", "22071020011111",
                                  "22071020022222", "22071020033333"]
    assert s[0].name == "Aagana Patel" and s[0].email == "aagana@msu.edu.in"
    assert s[0].admission_category == "Regular Admission to First Year"
    assert [x.is_pass for x in s] == [True, True, False, True, False]
    assert s[4].status == "Fail"          # " fail " is cleaned up


def test_load_students_pass_only_sheet_treats_everyone_as_pass(pass_only_sheet):
    s = load_students(pass_only_sheet, FD)
    assert [x.reg for x in s] == ["22071020016005", "22071020022222"]
    assert all(x.is_pass and x.status == "Pass" for x in s)
    assert all(x.programme == FD for x in s)


def test_load_students_without_registration_column_raises(tmp_path):
    from openpyxl import Workbook
    wb = Workbook(); wb.active.append(["Name", "Email"]); p = tmp_path / "bad.xlsx"; wb.save(p)
    with pytest.raises(ValueError, match="Registration"):
        load_students(p, FD)
```

### `tests/test_pdfinfo.py`

```python
from pathlib import Path
from sorter.pdfinfo import parse_transcript_text, read_pdf

SAMPLE = Path(__file__).parent / "fixtures" / "Aarpita_Dhoot_sample.pdf"


def test_parse_text_reads_name_and_reg():
    t = "ACADEMIC TRANSCRIPT\nName of the Student  : Aarpita Dhoot\nRegistration No. : 22071010029014\n"
    assert parse_transcript_text(t) == ("Aarpita Dhoot", "22071010029014")


def test_parse_text_handles_same_line_layout():
    t = "Name of the Student : Aagana Patel     Registration No. : 22071020016005   SCHOOL OF DESIGN"
    assert parse_transcript_text(t) == ("Aagana Patel", "22071020016005")


def test_parse_text_missing_fields():
    assert parse_transcript_text("hello") == ("", "")


def test_read_real_sample_pdf():
    info = read_pdf(SAMPLE)
    assert info.reg == "22071010029014" and info.name == "Aarpita Dhoot" and info.error == ""


def test_read_pdf_falls_back_to_file_name_for_name(tmp_path):
    from tests.conftest import make_pdf
    p = make_pdf(tmp_path / "Riya Sen_abc123.pdf", "", "123")
    info = read_pdf(p)
    assert info.reg == "123" and info.name == "Riya Sen"


def test_read_broken_pdf_reports_error(tmp_path):
    p = tmp_path / "x.pdf"; p.write_bytes(b"garbage")
    info = read_pdf(p)
    assert info.reg == "" and info.error
```

### `tests/test_classify.py`

```python
from sorter.classify import classify
from sorter.models import Student, PdfInfo
from pathlib import Path

FD = "Bachelor of Vocation in Fashion Design"


def st(reg, name, status):
    return Student(name=name, reg=reg, email="", programme=FD, admission_category="", status=status)


def pdf(reg, name, file="f.pdf", error=""):
    return PdfInfo(path=Path(file), name=name, reg=reg, error=error)


def test_four_buckets():
    students = [st("1", "A", "Pass"), st("2", "B", "Fail"), st("3", "C", "Pass"), st("4", "D", "Fail")]
    pdfs = [pdf("1", "A", "a.pdf"), pdf("2", "B", "b.pdf"), pdf("9", "Z", "z.pdf")]
    r = classify(students, pdfs, other_programmes={})
    assert [m.student.reg for m in r.passed] == ["1"]
    assert [m.student.reg for m in r.failed] == ["2"]
    assert [s.reg for s in r.no_pdf] == ["3", "4"]
    assert [(p.reg, why) for p, why in r.not_in_sheet] == [("9", "Not found in SOD sheet")]


def test_pdf_of_other_programme_is_explained():
    r = classify([], [pdf("7", "X")], other_programmes={"7": "Bachelor of Design in Interior Design"})
    assert r.not_in_sheet[0][1] == "In SOD sheet under another programme: Bachelor of Design in Interior Design"


def test_unreadable_pdf_goes_to_not_in_sheet():
    r = classify([], [pdf("", "", error="bad file")], other_programmes={})
    assert "Could not read Registration No." in r.not_in_sheet[0][1]


def test_duplicate_pdf_for_same_student_only_first_moved():
    r = classify([st("1", "A", "Pass")], [pdf("1", "A", "a.pdf"), pdf("1", "A", "a_copy.pdf")], {})
    assert len(r.passed) == 1 and r.passed[0].pdf.path.name == "a.pdf"
    assert r.not_in_sheet[0][1].startswith("Duplicate PDF")


def test_duplicate_student_rows_counted_once():
    r = classify([st("1", "A", "Pass"), st("1", "A", "Pass")], [pdf("1", "A")], {})
    assert len(r.passed) == 1 and r.no_pdf == []
```

### `tests/test_pipeline.py`

```python
from openpyxl import load_workbook
from sorter.pipeline import run
from tests.conftest import FD


def test_full_run_with_sod_sheet(full_sheet, pdf_dir, tmp_path):
    out = tmp_path / "out"
    res = run(full_sheet, FD, sorted(pdf_dir.glob("*.pdf")), out)

    folder = res.pass_folder
    assert folder.name == "BVoc FD Pass" and folder.is_dir()
    assert sorted(p.name for p in folder.iterdir()) == ["Aagana_1.pdf", "Abonita_2.pdf"]
    assert res.counts == {"passed": 2, "failed": 1, "no_pdf": 2, "not_in_sheet": 3}

    wb = load_workbook(res.report_path)
    assert wb.sheetnames == ["1. Pass - Moved", "2. Fail - Not Moved", "3. In Sheet - No PDF",
                             "4. PDF - Not In Sheet", "Summary"]
    s1 = list(wb["1. Pass - Moved"].values)
    assert s1[0][:4] == ("S.No", "Name (Sheet)", "Registration Number", "Email")
    assert {r[2] for r in s1[1:]} == {"22071020016005", "22071020029002"}
    s3 = list(wb["3. In Sheet - No PDF"].values)
    assert {(r[2], r[3]) for r in s3[1:]} == {("22071020022222", "Pass"), ("22071020033333", "Fail")}
    assert all(r[4] == "Not found in PDFs you provided" for r in s3[1:])
    s4 = {r[3]: r[4] for r in list(wb["4. PDF - Not In Sheet"].values)[1:]}
    assert s4["Stranger_4.pdf"] == "Not found in SOD sheet"
    assert s4["Aarpita_5.pdf"].startswith("In SOD sheet under another programme")
    assert "Could not read" in s4["broken.pdf"]


def test_full_run_with_pass_only_sheet(pass_only_sheet, pdf_dir, tmp_path):
    res = run(pass_only_sheet, FD, sorted(pdf_dir.glob("*.pdf")), tmp_path / "o")
    assert res.counts["passed"] == 1 and res.counts["failed"] == 0
    assert res.counts["no_pdf"] == 1          # 22071020022222 has no PDF


def test_rerun_does_not_overwrite_previous_output(full_sheet, pdf_dir, tmp_path):
    a = run(full_sheet, FD, sorted(pdf_dir.glob("*.pdf")), tmp_path / "o")
    b = run(full_sheet, FD, sorted(pdf_dir.glob("*.pdf")), tmp_path / "o")
    assert a.pass_folder != b.pass_folder and b.pass_folder.is_dir()
```

### `tests/test_app.py`

```python
import io, zipfile
import pytest
from app import create_app
from tests.conftest import FD, ID


@pytest.fixture
def client(tmp_path):
    return create_app(tmp_path / "work").test_client()


def test_home_page_uses_times_new_roman(client):
    html = client.get("/").get_data(as_text=True)
    assert "Times New Roman" in html and "programme" in html.lower()


def test_programmes_endpoint(client, full_sheet):
    r = client.post("/api/programmes", data={"sheet": (open(full_sheet, "rb"), "sod.xlsx")})
    assert r.get_json()["programmes"] == [{"name": FD, "short": "BVoc FD"}, {"name": ID, "short": "BVoc ID"}]


def test_process_and_download(client, full_sheet, pdf_dir):
    data = {"sheet": (open(full_sheet, "rb"), "sod.xlsx"), "programme": FD,
            "pdfs": [(open(p, "rb"), p.name) for p in sorted(pdf_dir.glob("*.pdf"))]}
    r = client.post("/api/process", data=data, content_type="multipart/form-data")
    j = r.get_json()
    assert r.status_code == 200 and j["counts"]["passed"] == 2
    z = zipfile.ZipFile(io.BytesIO(client.get(j["download"]).data))
    names = z.namelist()
    assert "BVoc FD Pass/Aagana_1.pdf" in names and any(n.endswith("Report.xlsx") for n in names)


def test_process_requires_programme_and_pdfs(client, full_sheet):
    r = client.post("/api/process", data={"sheet": (open(full_sheet, "rb"), "s.xlsx")})
    assert r.status_code == 400
```

Empty files `sorter/__init__.py` and `tests/__init__.py` are also needed. `tests/fixtures/Aarpita_Dhoot_sample.pdf` is a real transcript used by one test.
